$ErrorActionPreference = "Stop"

$PackageDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$QuPathUserDir = if ($env:QUPATH_USER_DIR) { $env:QUPATH_USER_DIR } else { Join-Path $env:USERPROFILE "QuPath\v0.6" }
if (-not $env:QUPATH_USER_DIR) {
    Write-Host "Check QuPath Preferences > User directory, then close QuPath."
    $SelectedFolder = Read-Host "Press Enter for $QuPathUserDir, or paste your custom QuPath user directory"
    if (-not [string]::IsNullOrWhiteSpace($SelectedFolder)) { $QuPathUserDir = $SelectedFolder.Trim('"') }
}
$Architecture = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
if ($Architecture -ne "X64") {
    throw "This package supports Windows x64 only. Windows ARM64 needs a separately tested runtime; ask the study coordinator."
}
$ExtensionsDir = Join-Path $QuPathUserDir "extensions"
$SupportDir = Join-Path $QuPathUserDir "timestamp"
$RuntimeDir = Join-Path $SupportDir "runtime"
$VenvDir = Join-Path $RuntimeDir ".venv"
$ToolsDir = Join-Path $SupportDir "tools"
$ModelCacheDir = Join-Path $SupportDir "model-cache"
$UvBin = Join-Path $ToolsDir "uv.exe"
$UvVersion = "0.12.5"
$RequirementsFile = Join-Path $PackageDir "requirements-doctor.txt"
$ChecksumsFile = Join-Path $PackageDir "CHECKSUMS-SHA256.txt"
$HelperFile = Join-Path $PackageDir "live_whisper_demo.py"
$ModelSetupFile = Join-Path $PackageDir "prepare_doctor_models.py"

Write-Host "TimeStamp doctor installation for Windows"
Write-Host "QuPath folder: $QuPathUserDir"
Write-Host ""
Write-Host "QuPath 0.6 must be opened once to complete its first-time setup, then closed."
Write-Host ""

if (Get-Process -Name "QuPath*" -ErrorAction SilentlyContinue) {
    throw "Please close QuPath completely, then run this installer again."
}
if (-not (Test-Path -LiteralPath $RequirementsFile -PathType Leaf)) { throw "Missing $RequirementsFile" }
if (-not (Test-Path -LiteralPath $ChecksumsFile -PathType Leaf)) { throw "Missing $ChecksumsFile" }
if (-not (Test-Path -LiteralPath $HelperFile -PathType Leaf)) { throw "Missing $HelperFile" }

$JarFile = Get-ChildItem -LiteralPath $PackageDir -Filter "TimeStamp-*.jar" -File |
    Where-Object { $_.Name -notmatch "-(javadoc|sources)\.jar$" } |
    Select-Object -First 1
if (-not $JarFile) { throw "The TimeStamp extension JAR is missing from this package." }

if (-not (Test-Path -LiteralPath $ModelSetupFile -PathType Leaf)) { throw "Missing $ModelSetupFile" }

Write-Host "[1/4] Verifying the TimeStamp package..."
$ExpectedChecksums = @{}
Get-Content -LiteralPath $ChecksumsFile | ForEach-Object {
    if ($_ -match '^([0-9a-fA-F]{64})\s+\*?(.+)$') { $ExpectedChecksums[$Matches[2]] = $Matches[1].ToLowerInvariant() }
}
foreach ($FileName in @($JarFile.Name, "requirements-doctor.txt", "live_whisper_demo.py", "prepare_doctor_models.py", "DOCTOR-INSTALL.txt", "Install TimeStamp.command", "Install TimeStamp on Linux.sh", "Install TimeStamp on Windows.bat", "Install-TimeStamp.ps1")) {
    if (-not $ExpectedChecksums.ContainsKey($FileName)) { throw "Missing checksum for $FileName" }
    $Actual = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $PackageDir $FileName)).Hash.ToLowerInvariant()
    if ($Actual -ne $ExpectedChecksums[$FileName]) { throw "Checksum verification failed for $FileName" }
    Write-Host "$FileName`: OK"
}

New-Item -ItemType Directory -Force -Path $ExtensionsDir, $RuntimeDir, $ToolsDir, $ModelCacheDir | Out-Null

if (-not (Test-Path -LiteralPath $UvBin -PathType Leaf)) {
    $Architecture = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
    switch ($Architecture) {
        "X64" {
            $UvPlatform = "x86_64-pc-windows-msvc"
            $UvSha256 = "4c4d49d8738847d9b71ba319e49a5688c93eac0fe6204b1df24e98528dddf39a"
        }
        default { throw "Unsupported Windows architecture: $Architecture" }
    }
    $TempDir = Join-Path ([System.IO.Path]::GetTempPath()) ("timestamp-uv-" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $TempDir | Out-Null
    try {
        $Archive = Join-Path $TempDir "uv.zip"
        Write-Host "Downloading the private TimeStamp setup tool..."
        Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/astral-sh/uv/releases/download/$UvVersion/uv-$UvPlatform.zip" -OutFile $Archive
        $ActualUvSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $Archive).Hash.ToLowerInvariant()
        if ($ActualUvSha256 -ne $UvSha256) { throw "The downloaded setup tool failed checksum verification." }
        Expand-Archive -LiteralPath $Archive -DestinationPath $TempDir -Force
        $DownloadedUv = Get-ChildItem -LiteralPath $TempDir -Filter "uv.exe" -File -Recurse | Select-Object -First 1
        if (-not $DownloadedUv) { throw "The downloaded setup tool did not contain uv.exe." }
        Copy-Item -LiteralPath $DownloadedUv.FullName -Destination "$UvBin.new" -Force
        Move-Item -LiteralPath "$UvBin.new" -Destination $UvBin -Force
    }
    finally {
        Remove-Item -LiteralPath $TempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

$env:UV_CACHE_DIR = Join-Path $SupportDir "download-cache"
$env:UV_PYTHON_INSTALL_DIR = Join-Path $RuntimeDir "python"
$env:HF_HOME = $ModelCacheDir

$PythonBin = Join-Path $VenvDir "Scripts\python.exe"
Write-Host "[2/4] Preparing the private recorder runtime..."
if (-not (Test-Path -LiteralPath $PythonBin -PathType Leaf)) {
    & $UvBin venv --python 3.12 --managed-python $VenvDir
    if ($LASTEXITCODE -ne 0) { throw "Private Python setup failed." }
}
Write-Host "Installing the recorder and speech-to-text libraries..."
& $UvBin pip install --python $PythonBin --requirements $RequirementsFile
if ($LASTEXITCODE -ne 0) { throw "Recorder dependency installation failed." }

if ($env:TIMESTAMP_SKIP_MODEL_DOWNLOAD -ne "1") {
    Write-Host "[3/4] Preparing speech models (first setup is the largest download)..."
    & $PythonBin $ModelSetupFile --validate
    if ($LASTEXITCODE -ne 0) { throw "Speech model preparation failed." }
}

Write-Host "[4/4] Checking the recorder and installing TimeStamp..."
& $PythonBin -c 'import faster_whisper, numpy, sounddevice; devices=sounddevice.query_devices(); print(f"Recorder ready; {len(devices)} audio device(s) detected")'
if ($LASTEXITCODE -ne 0) { throw "Recorder verification failed. If a DLL is missing, ask IT to install the Microsoft Visual C++ 2015–2022 x64 runtime and rerun setup." }
if ($env:TIMESTAMP_SKIP_AUDIO_CHECK -ne "1") {
    Write-Host "Testing the microphone for 5 seconds. Please say a sentence now (no patient information)..."
    & $PythonBin $HelperFile --check-audio --check-seconds 5 --plain
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "The microphone test could not open an input. Installation will finish; use Test microphone in QuPath after checking Windows privacy permissions."
    }
}

$InstallTarget = Join-Path $ExtensionsDir $JarFile.Name
$BackupDir = Join-Path $SupportDir ("extension-backups\" + [DateTime]::UtcNow.ToString("yyyyMMddTHHmmss") + "-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
Get-ChildItem -LiteralPath $ExtensionsDir -Filter "TimeStamp-*.jar" -File | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $BackupDir
}
Copy-Item -LiteralPath $JarFile.FullName -Destination "$InstallTarget.new" -Force
Get-ChildItem -LiteralPath $ExtensionsDir -Filter "TimeStamp-*.jar" -File | ForEach-Object {
    if ($_.FullName -ne $InstallTarget) { Remove-Item -LiteralPath $_.FullName -Force }
}
if (Test-Path -LiteralPath $InstallTarget -PathType Leaf) {
    Copy-Item -LiteralPath "$InstallTarget.new" -Destination $InstallTarget -Force
    Remove-Item -LiteralPath "$InstallTarget.new" -Force
} else {
    Move-Item -LiteralPath "$InstallTarget.new" -Destination $InstallTarget
}

$Manifest = [ordered]@{
    runtime = $PythonBin
    modelCache = $ModelCacheDir
    liveModel = "Systran/faster-whisper-small.en"
    finalModel = "Systran/faster-whisper-large-v3"
    installedAtUtc = [DateTime]::UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ")
}
$Manifest | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $SupportDir "doctor-runtime.json") -Encoding UTF8

Write-Host ""
Write-Host "TimeStamp is ready for the doctor."
Write-Host "Open QuPath 0.6, allow microphone access, then open the TimeStamp monitor."
